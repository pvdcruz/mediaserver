This folder contains a dummy self-signed certificate only for demo purposses,
**DON'T USE IT IN PRODUCTION**.
